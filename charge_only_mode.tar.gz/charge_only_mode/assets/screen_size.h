#define PNG_TOP         71
#define PNG_BOTTOM      317
#define PNG_LEFT        105


